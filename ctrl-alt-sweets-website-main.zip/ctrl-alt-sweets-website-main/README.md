Update 3

This is sample Python Flask application.

Credit goes to https://github.com/dave-mccollough/python_flask_demo for the fork
